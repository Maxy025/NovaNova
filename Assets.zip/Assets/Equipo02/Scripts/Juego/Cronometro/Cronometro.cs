using Assets.Scripts.Juego.Jugador;
using System.Collections;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class Cronometro : MonoBehaviour
{
    public float tiempo;

    public float contador = 0;
    public float contadorTotal = 0;

    public GameObject gameOver;
    public TMP_Text textoTitulo;
    public TMP_Text textoTiempo;
    public TMP_Text textoPuntos;

    public TMP_Text textoCronometro;

    public GameObject gameManager;
    public Lista listas;

    private bool sonidoUltimos30 = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        gameManager = GameObject.Find("GameManager");

        contador = tiempo;
        gameOver = GameObject.Find("GameOver");
        listas = gameManager.GetComponent<Lista>();
        textoTitulo = gameOver.transform.Find("Titulo").GetComponent<TMP_Text>();
        textoTiempo = gameOver.transform.Find("tempo").GetComponent<TMP_Text>();
        textoPuntos = gameOver.transform.Find("puntos").GetComponent<TMP_Text>();

        textoCronometro = GameObject.Find("Cronometro").GetComponentInChildren<TMP_Text>();

        
        StartCoroutine(DesactivarGameOver());
    }

    private IEnumerator DesactivarGameOver()
    {
        yield return null;
        gameOver.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (contador <= 30 && !sonidoUltimos30)
        {
            sonidoUltimos30 = true;
            AudioManager.instance.PlayMusic(AudioManager.instance.bg_last30, true);
        }

        textoCronometro.text = Mathf.FloorToInt(contador).ToString();
        if (contador > 0)
        {
            contador -= 1 * Time.deltaTime;
            contadorTotal += 1 * Time.deltaTime;
        }
        else
        {
            CompararRecord();
            textoCronometro.text = 0.ToString();
            gameOver.SetActive(true);
            Time.timeScale = 0;
            Cursor.lockState = CursorLockMode.None;
            textoTiempo.text = Mathf.FloorToInt(contadorTotal).ToString();
            textoPuntos.text = DatosJugador.Puntos.ToString();
            Puntuaciones puntuaciones = gameManager.GetComponent<Puntuaciones>();
            puntuaciones.Estrellas();
        }
    }

    private void CompararRecord()
    {
        if (listas.listasCompletadas > listas.record)
        {
            PlayerPrefs.SetInt("record", listas.listasCompletadas);
            PlayerPrefs.Save();
            textoTitulo.text = "Nuevo record";
        }
    }
}
